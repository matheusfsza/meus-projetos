<?php
session_start();
include 'config.php';
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style.css">
<script src="script.js" defer></script>
</head>
<body>

<header>
<div class="logo">CardAPPio</div>

<?php if (isset($_SESSION['usuarioLogado'])): ?>
<a href="meu_restaurante.php" class="btn-voltar">Meu Restaurante</a>
<?php endif; ?>

<a href="logout.php" class="btn-voltar">Sair</a>
</header>

<main>

<!-- PESQUISA -->
<input type="text" id="pesquisa" placeholder="Pesquisar restaurante...">

<!-- CONTAINER NECESSÁRIO PARA O JS -->
<div id="restaurantesContainer">
<?php
$res = $conn->query("SELECT * FROM Restaurante");
while ($r = $res->fetch_assoc()):
?>
<div class="item">
    <h3><?= $r['nome'] ?></h3>
    <p><?= $r['descricao'] ?></p>
    <p><?= $r['localizacao'] ?></p>
    <a href="ver_restaurante.php?id=<?= $r['id_restaurante'] ?>" class="botao">
        Ver Restaurante →
    </a>
</div>
<?php endwhile; ?>
</div>

</main>
</body>
</html>
