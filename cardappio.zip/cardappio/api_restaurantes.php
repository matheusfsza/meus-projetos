<?php
include 'config.php';
header("Content-Type: application/json");

$res = $conn->query("SELECT * FROM Restaurante");
$dados = [];

while($r = $res->fetch_assoc()){
    $dados[] = $r;
}

echo json_encode($dados);
