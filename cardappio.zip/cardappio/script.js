document.addEventListener("DOMContentLoaded", () => {
    // Menu do usuário
    const areaUsuario = document.getElementById("areaUsuario");
    if (areaUsuario) {
        areaUsuario.addEventListener("click", toggleMenu);
    }

    // Pesquisa de restaurantes
    const pesquisa = document.getElementById("pesquisa");
    if (pesquisa) {
        pesquisa.addEventListener("keyup", pesquisarRestaurantes);
    }
});

/* =========================
   MENU DO USUÁRIO
========================= */
function toggleMenu() {
    const menu = document.getElementById("menuUser");
    if (!menu) return;

    menu.style.display = menu.style.display === "flex" ? "none" : "flex";
}

/* =========================
   PESQUISA DE RESTAURANTES
========================= */
function pesquisarRestaurantes() {
    const termo = document.getElementById("pesquisa").value.toLowerCase();
    const itens = document.querySelectorAll("#restaurantesContainer .item");

    itens.forEach(item => {
        const texto = item.innerText.toLowerCase();
        item.style.display = texto.includes(termo) ? "block" : "none";
    });
}

/* =========================
   SAIR
========================= */
function sair() {
    window.location.href = "logout.php";
}
