<?php
include 'config.php';

$id = intval($_GET['id']);

$r = $conn->query("SELECT * FROM Restaurante WHERE id_restaurante=$id")->fetch_assoc();
$p = $conn->query("SELECT * FROM Prato WHERE restaurante_id=$id");
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($r['nome']) ?> - Cardápio</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <div class="logo">CardAPPio</div>
    <button class="btn-voltar" onclick="window.history.back()">← Voltar</button>
</header>

<main class="ver-restaurante">

    <section class="info-restaurante">
        <h1><?= htmlspecialchars($r['nome']) ?></h1>
        <p class="descricao"><?= htmlspecialchars($r['descricao'] ?? '') ?></p>
        <p class="localizacao"><?= htmlspecialchars($r['localizacao'] ?? '') ?></p>
    </section>

    <section class="cardapio">
        <h2>Cardápio</h2>

        <?php if ($p->num_rows == 0): ?>
            <p class="mensagem">Este restaurante ainda não cadastrou pratos.</p>
        <?php else: ?>
            <div class="lista-pratos">
                <?php while ($pr = $p->fetch_assoc()): ?>
                    <div class="pratoItem">
                        <?php if (!empty($pr['imagem'])): ?>
                            <img src="uploads/<?= htmlspecialchars($pr['imagem']) ?>" alt="<?= htmlspecialchars($pr['nome']) ?>">
                        <?php endif; ?>

                        <div class="info-prato">
                            <h3><?= htmlspecialchars($pr['nome']) ?></h3>
                            <p><?= htmlspecialchars($pr['descricao'] ?? '') ?></p>
                            <span class="preco">R$ <?= number_format($pr['preco'], 2, ',', '.') ?></span>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php endif; ?>
    </section>

</main>

</body>
</html>
