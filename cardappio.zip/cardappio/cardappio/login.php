<?php
session_start();
include 'config.php';

if(isset($_POST['entrar'])){
    $email = $_POST['email'];

    $sql = "SELECT * FROM Usuario WHERE email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s",$email);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows > 0){
        $_SESSION['usuarioLogado'] = $email;
        header("Location: explorar.php");
        exit;
    } else {
        $erro = "Usuário não encontrado!";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>CardAPPio - Login</title>
<link rel="stylesheet" href="./style.css">

</head>
<body class="login-body">

<div class="login-box animate-fade">
    <h1>CardAPPio</h1>
    <h2>Login</h2>

    <?php if(isset($erro)) { echo "<p style='color:red;'>$erro</p>"; } ?>

    <form method="POST">
        <input type="email" name="email" placeholder="Email" required>
        <button type="submit" name="entrar">Entrar</button>
    </form>

    <a href="cadastrar.php">Cadastre-se</a>
    <button class="btn-login-convidado" onclick="window.location.href='explorar.php?convidado=1'">Entrar como Convidado</button>
</div>

</body>
</html>
