<?php
session_start();
include 'config.php';

if (!isset($_SESSION['usuarioLogado'])) {
    header("Location: login.php");
    exit;
}

/* ADICIONAR / EDITAR PRATO */
if (isset($_POST['salvar_prato'])) {

    $id_prato = $_POST['id_prato'] ?? null;
    $restaurante_id = $_POST['restaurante_id'];
    $nome = $_POST['nome'];
    $descricao = $_POST['descricao'];
    $preco = $_POST['preco'];

    $imagem = null;

    if (!empty($_FILES['imagem']['name'])) {
        $imagem = time() . "_" . $_FILES['imagem']['name'];
        move_uploaded_file($_FILES['imagem']['tmp_name'], "uploads/$imagem");
    }

    if ($id_prato) {
        /* EDITAR */
        if ($imagem) {
            $stmt = $conn->prepare(
                "UPDATE Prato SET nome=?, descricao=?, preco=?, imagem=? WHERE id_prato=?"
            );
            $stmt->bind_param("ssdsi", $nome, $descricao, $preco, $imagem, $id_prato);
        } else {
            $stmt = $conn->prepare(
                "UPDATE Prato SET nome=?, descricao=?, preco=? WHERE id_prato=?"
            );
            $stmt->bind_param("ssdi", $nome, $descricao, $preco, $id_prato);
        }
        $stmt->execute();

    } else {
        /* ADICIONAR */
        $stmt = $conn->prepare(
            "INSERT INTO Prato (nome, descricao, preco, imagem, restaurante_id)
             VALUES (?,?,?,?,?)"
        );
        $stmt->bind_param("ssdsi", $nome, $descricao, $preco, $imagem, $restaurante_id);
        $stmt->execute();
    }

    header("Location: meu_restaurante.php");
    exit;
}

/* EXCLUIR PRATO */
if (isset($_GET['excluir'])) {
    $id = $_GET['excluir'];

    $stmt = $conn->prepare("DELETE FROM Prato WHERE id_prato=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    header("Location: meu_restaurante.php");
    exit;
}
