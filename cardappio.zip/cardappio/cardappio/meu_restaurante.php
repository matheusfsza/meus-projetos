<?php
session_start();
include 'config.php';

if (!isset($_SESSION['usuarioLogado'])) {
    header("Location: login.php");
    exit;
}

$email = $_SESSION['usuarioLogado'];

/* USUÁRIO */
$stmt = $conn->prepare("SELECT id_usuario FROM Usuario WHERE email=?");
$stmt->bind_param("s", $email);
$stmt->execute();
$usuario = $stmt->get_result()->fetch_assoc();
$usuario_id = $usuario['id_usuario'];

/* RESTAURANTE */
$stmt = $conn->prepare("SELECT * FROM Restaurante WHERE usuario_id=?");
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$restaurante = $stmt->get_result()->fetch_assoc();

/* SALVAR / EDITAR RESTAURANTE */
if (isset($_POST['salvar_restaurante'])) {
    $nome = $_POST['nome'];
    $descricao = $_POST['descricao'];
    $localizacao = $_POST['localizacao'];

    if ($restaurante) {
        $stmt = $conn->prepare(
            "UPDATE Restaurante SET nome=?, descricao=?, localizacao=? WHERE usuario_id=?"
        );
        $stmt->bind_param("sssi", $nome, $descricao, $localizacao, $usuario_id);
    } else {
        $stmt = $conn->prepare(
            "INSERT INTO Restaurante (nome, descricao, localizacao, usuario_id)
             VALUES (?,?,?,?)"
        );
        $stmt->bind_param("sssi", $nome, $descricao, $localizacao, $usuario_id);
    }
    $stmt->execute();
    header("Location: meu_restaurante.php");
    exit;
}

/* PRATOS */
$pratos = [];
if ($restaurante) {
    $stmt = $conn->prepare("SELECT * FROM Prato WHERE restaurante_id=?");
    $stmt->bind_param("i", $restaurante['id_restaurante']);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($p = $res->fetch_assoc()) $pratos[] = $p;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Meu Restaurante</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <div class="logo">CardAPPio</div>
    <button class="btn-voltar" onclick="window.location.href='explorar.php'">← Voltar</button>
</header>

<main>

<h2>Meu Restaurante</h2>

<form method="POST" class="form-elegante">
    <input type="text" name="nome" placeholder="Nome do restaurante"
           value="<?= htmlspecialchars($restaurante['nome'] ?? '') ?>" required>

    <textarea name="descricao" placeholder="Descrição"><?= htmlspecialchars($restaurante['descricao'] ?? '') ?></textarea>

    <input type="text" name="localizacao" placeholder="Localização"
           value="<?= htmlspecialchars($restaurante['localizacao'] ?? '') ?>">

    <button type="submit" name="salvar_restaurante">Salvar Restaurante</button>
</form>

<?php if ($restaurante): ?>

<hr>

<div class="topo-pratos">
    <h3>Pratos (<?= count($pratos) ?>)</h3>
    <button onclick="abrirModal()">+ Adicionar Prato</button>
</div>

<div class="lista-pratos">
<?php foreach ($pratos as $p): ?>
    <div class="card-prato">
        <?php if ($p['imagem']): ?>
            <img src="uploads/<?= htmlspecialchars($p['imagem']) ?>">
        <?php endif; ?>
        <strong><?= htmlspecialchars($p['nome']) ?></strong>
        <span>R$ <?= number_format($p['preco'], 2, ',', '.') ?></span>
        <div class="acoes-prato">
            <button onclick="editarPrato(
                <?= $p['id_prato'] ?>,
                '<?= htmlspecialchars($p['nome'], ENT_QUOTES) ?>',
                '<?= htmlspecialchars($p['descricao'], ENT_QUOTES) ?>',
                <?= $p['preco'] ?>
            )">✏️</button>

            <a href="meus_pratos.php?excluir=<?= $p['id_prato'] ?>&rid=<?= $restaurante['id_restaurante'] ?>"
               onclick="return confirm('Excluir prato?')">🗑</a>
        </div>
    </div>
<?php endforeach; ?>
</div>

<?php endif; ?>

</main>

<!-- MODAL -->
<div id="modal" class="modal">
    <div class="modal-box">
        <h3 id="modalTitulo">Adicionar Prato</h3>

        <form method="POST" action="meus_pratos.php" enctype="multipart/form-data">
            <input type="hidden" name="id_prato" id="id_prato">
            <input type="hidden" name="restaurante_id" value="<?= $restaurante['id_restaurante'] ?? '' ?>">

            <input type="text" name="nome" id="nome_prato" placeholder="Nome do prato" required>
            <textarea name="descricao" id="descricao_prato" placeholder="Descrição"></textarea>
            <input type="number" step="0.01" name="preco" id="preco_prato" placeholder="Preço" required>
            <input type="file" name="imagem">

            <div class="modal-acoes">
                <button type="submit" name="salvar_prato">Salvar</button>
                <button type="button" onclick="fecharModal()">Cancelar</button>
            </div>
        </form>
    </div>
</div>

<script>
function abrirModal(){
    document.getElementById("modal").style.display = "flex";
}
function fecharModal(){
    document.getElementById("modal").style.display = "none";
}
function editarPrato(id,nome,descricao,preco){
    abrirModal();
    document.getElementById("modalTitulo").innerText="Editar Prato";
    document.getElementById("id_prato").value=id;
    document.getElementById("nome_prato").value=nome;
    document.getElementById("descricao_prato").value=descricao;
    document.getElementById("preco_prato").value=preco;
}
</script>

</body>
</html>
