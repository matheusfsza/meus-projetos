<?php
session_start();
include 'config.php';
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header>
<div class="logo">CardAPPio</div>
<?php if (isset($_SESSION['usuarioLogado'])): ?>
<a href="meu_restaurante.php" class="btn-voltar">Meu Restaurante</a>
<a href="logout.php" class="btn-voltar">Sair</a>
<?php endif; ?>
</header>

<main>
<?php
$res = $conn->query("SELECT * FROM Restaurante");
while ($r = $res->fetch_assoc()):
?>
<div class="item">
<h3><?= $r['nome'] ?></h3>
<p><?= $r['descricao'] ?></p>
<p><?= $r['localizacao'] ?></p>
<a href="ver_restaurante.php?id=<?= $r['id_restaurante'] ?>">Ver</a>
</div>
<?php endwhile; ?>
</main>
</body>
</html>