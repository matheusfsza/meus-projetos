<?php
session_start();

// Verifica se é convidado
$convidado = isset($_GET['convidado']) && $_GET['convidado'] == 1;

// Se não for convidado e não tiver usuário logado, redireciona para login
if(!$convidado && !isset($_SESSION['usuarioLogado'])){
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>CardAPPio</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <div class="logo">CardAPPio</div>
    <?php if(!$convidado): ?>
    <div id="areaUsuario" onclick="toggleMenu()">
        <div id="iconeUser">U</div>
        <span id="nomeUser"><?php echo $_SESSION['usuarioLogado'] ?? ''; ?></span>
    </div>
    <div id="menuUser">
        <button onclick="window.location.href='restaurante.php'">Meu Restaurante</button>
        <button onclick="window.location.href='sair.php'">Sair</button>
    </div>
    <?php endif; ?>
</header>

<main class="explorar-main animate-fade">
    <input type="text" id="pesquisaRestaurante" placeholder="Buscar restaurante...">
    <div id="restaurantesContainer"></div>
    <div id="mensagem" class="mensagem"></div>
</main>

<script>
const container = document.getElementById('restaurantesContainer');
const mensagem = document.getElementById('mensagem');
const pesquisa = document.getElementById('pesquisaRestaurante');

function carregarRestaurantes(){
    container.innerHTML="";
    let restaurantes = JSON.parse(localStorage.getItem("restaurantes")||"[]");
    const filtro = pesquisa.value.toLowerCase();
    let encontrados = restaurantes.filter(r=> r.nome.toLowerCase().includes(filtro));

    if(encontrados.length===0){
        mensagem.textContent="Poxa vida! Nenhum restaurante encontrado.";
        return;
    }else{
        mensagem.textContent="";
    }

    encontrados.forEach(rest=>{
        const div = document.createElement('div');
        div.className="item";
        div.innerHTML=`<h3>${rest.nome}</h3><p>${rest.endereco}</p>`;
        div.addEventListener('click', ()=>verRestaurante(rest.email));
        container.appendChild(div);
    });
}

function verRestaurante(email){
    localStorage.setItem("verRestaurante", email);
    window.location.href="restaurante.php";
}

pesquisa.addEventListener('input', carregarRestaurantes);
window.addEventListener('load', carregarRestaurantes);
</script>

</body>
</html>
