<?php
session_start();
include 'config.php';

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $nome = $_POST['nome'];
    $desc = $_POST['descricao'];
    $loc  = $_POST['localizacao'];
    $user = $_SESSION['usuario_id'];

    $stmt = $conn->prepare(
        "INSERT INTO restaurante (nome, descricao, localizacao, usuario_id)
         VALUES (?,?,?,?)"
    );
    $stmt->bind_param("sssi",$nome,$desc,$loc,$user);
    $stmt->execute();

    header("Location: explorar.php");
}
?>
<form method="POST">
<input name="nome" placeholder="Nome">
<textarea name="descricao"></textarea>
<input name="localizacao">
<button>Criar Restaurante</button>
</form>
