<?php
session_start();
include 'config.php';

if (isset($_POST['cadastrar'])) {
    $nome = $_POST['nome'];
    $email = $_POST['email'];

    $stmt = $conn->prepare("INSERT INTO Usuario (nome,email) VALUES (?,?)");
    $stmt->bind_param("ss", $nome, $email);

    if ($stmt->execute()) {
        $_SESSION['usuarioLogado'] = $email;
        header("Location: explorar.php");
        exit;
    } else {
        $erro = "Erro ao cadastrar.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style.css">
</head>
<body class="login-body">
<div class="login-box">
<h1>Cadastro</h1>
<form method="POST">
<input name="nome" placeholder="Nome" required>
<input name="email" type="email" placeholder="Email" required>
<button name="cadastrar">Cadastrar</button>
</form>
<p><?= $erro ?? "" ?></p>
</div>
</body>
</html>
